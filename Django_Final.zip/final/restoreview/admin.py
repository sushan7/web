from django.contrib import admin
from .models import restoinfo, restoinfo_test
# Register your models here.

admin.site.register(restoinfo)
admin.site.register(restoinfo_test)
