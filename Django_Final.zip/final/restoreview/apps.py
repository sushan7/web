from django.apps import AppConfig


class RestoreviewConfig(AppConfig):
    name = 'restoreview'
