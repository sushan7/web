# RestoView
Web Technology (UE17CS204) Mini-Project

A website where users get access to the menu of different restaurants.
